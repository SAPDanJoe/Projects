﻿Add-Type –AssemblyName System.Windows.Forms

<#Supporting functions for the script#>

function makeWorkingDir()
{
    if(!(Test-Path $workingDir)){
        New-Item $workingDir -ItemType Directory
    }
    else {
        $Response=([System.Windows.Forms.MessageBox]::Show("It looks like this script may have previoulsy been run incompletely.`nThe folder $workingDir already exists.`n How would you like to proceed?","Ooops!","AbortRetryIgnore","Warning"))
        if($Response -eq 'Abort'){exit}
        elseif ($Response -eq 'Retry'){makeWorkingDir}
        elseif ($Response -eq 'Ignore'){break}
        else{
            ([System.Windows.Forms.MessageBox]::Show('Script error: the error response: $Response was unhandled.'))
            exit
            }
     }
}

function ostBackup()
{
    <#Get a list of items in the outlook folder, before making any changes#>
    $before = Get-ChildItem $outlookDir
    "`nCurrent contents of outlook directory:`n"
    $before

    Move-Item $outlookDir\* $workingDir -force
    
    <#Get a list of items in the outlook folder after emptying it (to make sure it is empty)#>
    $empty = Get-ChildItem $outlookDir
    "`nContents of outlook directory after empty operation:`n"
    $empty

    if ($empty.Count -eq 0){

        <#If the folder was emptied successfully, create the backup folder in outlook and backup to it#>

        New-Item $backupDir -ItemType Directory
        Move-Item $workingDir\* $backupDir -Force
        Remove-Item $workingDir
    }
    else {
        
        <#Handle exception where the folder was not emptied successfully#>
        $Response=([System.Windows.Forms.MessageBox]::Show(
            "$outlookDir should be empty but it is not.`n" +
            "The folder contains " + $empty.Count + " files.`n `n" +
            "How would you like to proceed?","Ooops!","AbortRetryIgnore","Warning"))
        if($Response -eq 'Abort'){exit}
        elseif ($Response -eq 'Retry'){ostBackup}
        elseif ($Response -eq 'Ignore'){
            New-Item $backupDir -ItemType Directory
            Move-Item $workingDir\* $backupDir -Force
            Remove-Item $workingDir
        }
        else{
            ([System.Windows.Forms.MessageBox]::Show('Script error: the error response: $Response was unhandled.'))
            exit
           }
    }
     
    <#Now make sure that the number of files that were in the Outlook folder matches the number now in the backup folder#>
    $backedUp = Get-ChildItem $backupDir
    "`nContents of outlook backup directory after move operation:`n"
    $backedUp
    if(!($before.Count -eq $backedUp.Count)){
        <#Handle the exception where they do not match#>
        $Response=([System.Windows.Forms.MessageBox]::Show(
            "There was a problem backing up the outlook files.`n" +
            "$outlookDir contained " + $before.Count + " files when I started. `n" +
            "$outlookDir\ostBackup $scriptTime contains " + $backedUp.Count +" files.`n `n" +
            "Original Files:`n" +
            "$before `n `n" +
            "Backed-up Files: `n `n" +
            "$backedUp `n `n" +
            "How would you like to proceed?",
            "Ooops!",
            "AbortRetryIgnore",
            "Warning"))
        if($Response -eq 'Abort'){exit}
        elseif ($Response -eq 'Retry'){ostBackup}
        elseif ($Response -eq 'Ignore'){Break}
        else{
            ([System.Windows.Forms.MessageBox]::Show('Script error: the error response: $Response was unhandled.'))
            exit
            }
     }
}

function restartProc ()
{
    foreach ($restart in $restarts){
        Start-Process -FilePath $restart
        }
    exit
}

<#stop processes that may be using outlook files#>
$processes = "OUTLOOK", "communicator", "UcMapi", "eaclient"
$restarts = @()
foreach ($process in $processes){
    $testproc = Get-Process -name $process -ErrorAction Continue
    if (!($testproc.Count -eq 0)){        
        $restarts += $testproc.Path
    }
    do {
        
        Stop-Process -name $process
    }
    while(Get-Process $process -ErrorAction SilentlyContinue)
}

<#create a temp folder for the outlook profile backup (or warn if the folder already exists)#>
$scriptTime = get-date -Format 'dd-MM-yyy hhmm'
$workingDir = "$env:temp\ostBackup" + $scriptTime
$outlookDir = "$env:LOCALAPPDATA\Microsoft\Outlook"
$backupDir = "$env:LOCALAPPDATA\Microsoft\Outlook\ostBackup" + $scriptTime
makeWorkingDir
ostBackup
restartProc